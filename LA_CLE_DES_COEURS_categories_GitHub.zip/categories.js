/* LA CLÉ DES CŒURS — Catégories du catalogue
 * Les identifiants correspondent aux valeurs déjà utilisées dans produits.js :
 * accessoires, ap-swatch, femme, homme.
 * Les exemples sont des familles/modèles repérés, pas un inventaire exhaustif.
 */
(function () {
  "use strict";
  const CDC_CATEGORIES = {
  "accessoires": {
    "label": "Accessories et bracelets",
    "count_on_old_site": 76,
    "subcategories": [
      {
        "label": "Bagues",
        "examples": [
          "Cartier Trinity",
          "Cartier Trinité",
          "Bagues de fiançailles Cartier"
        ]
      },
      {
        "label": "Bracelets Cartier",
        "examples": [
          "Cartier Love en or jaune",
          "Cartier Love en or rose",
          "Cartier Love en or blanc",
          "Cartier Love avec diamants",
          "Cartier Juste un Clou",
          "Cartier Panthère",
          "Cartier Trinity",
          "Bracelets manchettes Cartier"
        ]
      },
      {
        "label": "Bracelets Van Cleef & Arpels",
        "examples": [
          "Alhambra",
          "Alhambra cornaline",
          "Alhambra onyx",
          "Alhambra malachite",
          "Alhambra nacre"
        ]
      },
      {
        "label": "Autres marques",
        "examples": [
          "Bracelets Fred Force 10",
          "Bracelets Tiffany & Co.",
          "Autres bijoux de grandes marques"
        ]
      }
    ]
  },
  "ap-swatch": {
    "label": "AP x Swatch",
    "count_on_old_site": 16,
    "subcategories": [
      {
        "label": "Collection Royal Pop en Bioceramic Swiss Made",
        "examples": [
          "Royal Pop Blaue Acht",
          "Royal Pop Green Eight",
          "Royal Pop Huit Blanc",
          "Royal Pop Lan Ba",
          "Royal Pop Ocho Negro",
          "Royal Pop Orenji Hachi",
          "Royal Pop Otg Roz",
          "Royal Pop Otto Rosso"
        ]
      }
    ]
  },
  "femme": {
    "label": "Montres femme",
    "count_on_old_site": 14,
    "subcategories": [
      {
        "label": "Modèles identifiés",
        "examples": [
          "Cartier Baignoire",
          "Cartier Panthère",
          "Cartier Tank Must",
          "Cartier Santos Carrée",
          "Cartier Santos Demoiselle",
          "Jaeger-LeCoultre Reverso",
          "Patek Philippe vintage",
          "Omega Seamaster Diver 300M 007",
          "Cartier Panthère Medium",
          "Cartier Panthère 2025",
          "Cartier Fabergé 67082"
        ]
      }
    ]
  },
  "homme": {
    "label": "Montres Homme",
    "count_on_old_site": 140,
    "subcategories": [
      {
        "label": "Marques et collections",
        "examples": [
          "Rolex Datejust",
          "Rolex Oyster Perpetual",
          "Tudor Submariner",
          "Tudor Black Bay",
          "Tudor Black Bay GMT",
          "Tudor Black Bay 58 GMT",
          "Omega Speedmaster",
          "Cartier Tank",
          "Cartier Santos",
          "Patek Philippe",
          "Autres montres de prestige"
        ]
      }
    ]
  }
};

  if (typeof window !== "undefined") {
    window.CDC_CATEGORIES = CDC_CATEGORIES;
  }
  if (typeof module !== "undefined" && module.exports) {
    module.exports = CDC_CATEGORIES;
  }
})();
