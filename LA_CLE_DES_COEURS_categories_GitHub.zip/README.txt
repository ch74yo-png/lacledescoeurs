LA CLÉ DES CŒURS — PACK CATÉGORIES

CONTENU
- categories.js : définition des quatre catégories, sous-familles, exemples de modèles et nombres annoncés sur l'ancien site.
- recapitulatif-categories.txt : copie lisible du récapitulatif fourni.

CATÉGORIES
1. Accessories et bracelets — 76 produits annoncés
2. AP x Swatch — 16 produits annoncés
3. Montres femme — 14 produits annoncés
4. Montres Homme — 140 produits annoncés

Produit supplémentaire du nouveau site :
- DETAILS — 2 €

IMPORTANT
Ce pack prépare les données de catégories. Ajouter categories.js dans GitHub ne suffit pas, à lui seul, à afficher des catégories sur le site : il faudra aussi le charger dans les pages concernées et relier les liens/menus de catégories à ces identifiants.

Les modèles cités dans le récapitulatif sont des exemples retrouvés, pas la liste complète des produits. Les totaux annoncés (246 par addition des catégories, contre 238 résultats affichés dans la boutique) doivent être revérifiés avant de les utiliser comme nombres définitifs.
